import os
import smtplib
from email import encoders
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart


def SendMail(sender:str, password:str, receiver:str, 
            subject:str, msg_body:str, attach_file_path=None):
    """
    Dependencies:
    import os
    import smtplib
    from email import encoders
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email.mime.multipart import MIMEMultipart
    """
    #Initialize and set message content
    message = MIMEMultipart()
    message['From'] = sender
    message['To'] = receiver
    message['Subject'] = subject

    try:
        #Try if attached_file_path is valid else send mail without attachment
        try:
            if attach_file_path:
                #Checked and continue if attached_file_path provided
                attachment = open(attach_file_path, "rb")
            else:
                #Invalid attached_file_path provided
                attachment = False
                msg_body += "\n\n\n>>Attachment: No attahment provided!"
        except Exception as e:
            attachment = False
            msg_body += "\n\n\n>>Attachment: Attached file path was invalid!"

        #Set message body
        message.attach(MIMEText(msg_body, 'plain'))

        if attachment:
            #Initalize attachment
            payload = MIMEBase('application', 'octet-stream')
            payload.set_payload((attachment).read())
            encoders.encode_base64(payload)

            #Get the file name with extension
            filename = os.path.basename(attach_file_path)
            payload.add_header('Content-Disposition', 'attachment', filename=filename)
            message.attach(payload)

        #Send mail even if dont have attached file
        session = smtplib.SMTP('smtp.gmail.com', 587)
        session.starttls()
        session.login(sender, password)
        session.sendmail(sender, receiver, message.as_string())
        
        #If it has attached file than close() file
        if attachment:
            attachment.close()
        session.quit()

    except Exception as e:
        # print('Error: ', e)
        return False


# try:
#     SendMail(
#             sender='example@gmail.com',
#             password=password,
#             receiver='example@gmail.com', 
#             subject='testing email subject', 
#             msg_body='main body for testing mail',
#         )
# except Exception as e:
#     print(e)
