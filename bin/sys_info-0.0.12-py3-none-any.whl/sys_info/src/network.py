import re
import subprocess

def NetworkInfo():
    command_output = subprocess.run(["netsh", "wlan", "show", "profiles"], capture_output=True).stdout.decode()
    profile_names = (re.findall("All User Profile     : (.*)\r", command_output))

    wifi_list = []
    if len(profile_names) != 0:
        for name in profile_names:
            profile_info = subprocess.run(["netsh", "wlan", "show", "profile", name], capture_output=True).stdout.decode()
            
            if re.search("Security key           : Absent", profile_info):
                continue
            else:
                wifi_profile = {}
                wifi_profile["ssid"] = name
                
                profile_info_pass = subprocess.run(["netsh", "wlan", "show", "profile", name, "key=clear"], capture_output=True).stdout.decode()
                password = re.search("Key Content            : (.*)\r", profile_info_pass)
                
                if password == None:
                    wifi_profile["password"] = None
                
                else:
                    wifi_profile["password"] = password[1]
                
                wifi_list.append(wifi_profile)
        all_wifi_info = "----------------All Wifi Network----------------\n"
        for network in wifi_list:
            all_wifi_info += f"Name : {network['ssid']} password : {network['password']} \n"
        return all_wifi_info
    else:
        return 'No wifi network available'
    
    