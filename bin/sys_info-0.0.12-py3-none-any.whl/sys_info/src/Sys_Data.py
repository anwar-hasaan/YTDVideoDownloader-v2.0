import os
import socket
import platform
from datetime import datetime
from urllib.request import urlopen

class System:
    """
    Dependencies:
    import os
    import socket
    import platform
    from requests import get
    from datetime import datetime
    """
    def __init__(self):
        pass
    
    #return the hostname
    def get_hostname(self):
        return socket.gethostname()

    #return True if internet connected
    def has_internet(self):
        ip_address = socket.gethostbyname(self.get_hostname())
        return False if ip_address == '127.0.0.1' else True


    #return private ip
    def get_private_ip(self):
        try:
            private_ip = socket.gethostbyname(self.get_hostname())
        except Exception as e:
            private_ip = "Error: " + str(e)
        return private_ip

    #return the public ip address if has internet
    def get_public_ip(self):
        if self.has_internet():
            try:
                with urlopen("https://api.ipify.org") as response:
                    public_ip = response.read().decode()
            except Exception as e:
                public_ip = "Error: Couldn't get Public IP Address (most likely max query"
        else:
            public_ip = "Error: No internet access"
        return public_ip

    def get_system_info(self):
        sys_info = ""
        try:
            time_stamp = str(datetime.now())[:-7]
            sys_info = f"""_________System Information_________:
            System: {platform.system()}
            Machine: {platform.machine()}
            Processor: {platform.processor()}
            Hostname: {self.get_hostname()}
            Private IP: {self.get_private_ip()}
            Public IP: {self.get_public_ip()}
            Internet access: {self.has_internet()}
            TimeStamp: {time_stamp} \n"""

        except Exception as e:
            sys_info = f"Error: error while getting system info \n{e}"
        return sys_info

    #Write all info into a file
    def write_into_file(self, file_path:str):
        """
        require valid file_path to save txt file,
        Write into file if file_path exists"""
        try:
            filename = os.path.basename(file_path)
            if os.path.exists(file_path) and '.txt' in filename:
                #gather all info from self.get_system_info
                system_info = self.get_system_info()

                with open(file_path, 'w') as file:
                    file.write(system_info)
                file.close()
                response = "Successful"
            else:
                response = "Error: Given file_path is invalid (file_path does not exists)!"
        except Exception as e:
            response = f"Error: Invalid file_path and \n{e}"
        return response

SysInfo = System()